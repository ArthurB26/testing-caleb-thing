import pygame
from scripts.data import get_data, save_data, save_user, quitApp
from scripts.messages import Messages
from scripts.buttons import button
import datetime


class App:
    def __init__(self):
        pygame.init()

        self.width, self.height = 1920, 1080
        pygame.display.set_caption("PyChat") 
        self.screen = pygame.display.set_mode((self.width, self.height), pygame.SCALED | pygame.FULLSCREEN)
        self.userdata = get_data('user')
        self.running = True
        self.canType = True
        self.FONT = pygame.font.Font('images/font.ttf', 40)
        self.cursor_font = pygame.font.Font('images/font.ttf', 40) 
        self.userFONT = pygame.font.Font('images/font.ttf', 70) 
        self.usercursorFONT = pygame.font.Font('images/font.ttf', 70) 
        pygame.mouse.set_cursor(*pygame.cursors.tri_left)
        
        self.messages = Messages(self.userdata, self.screen) 
        self.msgdata = self.messages.msgdata 

        self.example_user = {
            "Name": 'Someone',
            "pfp": "example.png",
            "started": False,
        }
        self.user_text = ""
        self.typing_username = ""
        self.wrapped_text = ['', '']
        self.chatBG = pygame.image.load("images/ui/chatBG.png").convert_alpha()
        self.chatBG = pygame.transform.scale(self.chatBG, (self.width, self.height))
        self.clearimg = pygame.transform.scale(pygame.image.load('images/ui/clear.png'), (50, 50))

        self.setupBG = pygame.image.load("images/ui/SetUp.png").convert_alpha()
        self.setupBG = pygame.transform.scale(self.setupBG, (self.width, self.height))

        self.pfps = []
        for i in range(1, 10, 1):
            self.pfps.append(f'pfp/{i}.png')
        self.tempPFP = 1
        self.down = False
        self.selected = pygame.transform.scale(pygame.image.load('images/ui/selected.png'), (30, 30))

    def app(self):

        def wrap_text(text, font, width):
            words = text.split(' ')
            wrapped_lines = []
            current_line = ""

            for word in words:
                test_line = current_line + word + " "
                if font.size(test_line)[0] <= width:
                    current_line = test_line
                else:
                    wrapped_lines.append(current_line)
                    current_line = word + " "

            if current_line:
                wrapped_lines.append(current_line)

            return wrapped_lines

        while not self.userdata.get('started'):
            self.screen.fill((0, 0, 0))
            self.screen.blit(self.setupBG, (0, 0))

            username_surface = self.userFONT.render(self.typing_username, True, (84, 84, 84))
            self.screen.blit(username_surface, (610, 380))

            cursor_color = (142, 239, 195) if pygame.time.get_ticks() // 500 % 2 else (84, 84, 84)
            cursor_surface = self.usercursorFONT.render("|", True, cursor_color)
            self.screen.blit(cursor_surface, (610 + self.userFONT.size(self.typing_username)[0], 380))
            px, py = 750, 565 
            if button(self.screen, self.pfps[0], (px + 0, py + 0), self.down) == 1: self.tempPFP = 1 
            if button(self.screen, self.pfps[1], (px + 150, py + 0), self.down) == 1: self.tempPFP = 2
            if button(self.screen, self.pfps[2], (px + 300, py + 0), self.down) == 1: self.tempPFP = 3
            if button(self.screen, self.pfps[3], (px + 0, py + 130), self.down) == 1: self.tempPFP = 4
            if button(self.screen, self.pfps[4], (px + 150, py + 130), self.down) == 1: self.tempPFP = 5
            if button(self.screen, self.pfps[5], (px + 300, py + 130), self.down) == 1: self.tempPFP = 6
            if button(self.screen, self.pfps[6], (px + 0, py + 260), self.down) == 1: self.tempPFP = 7
            if button(self.screen, self.pfps[7], (px + 150, py + 260), self.down) == 1: self.tempPFP = 8
            if button(self.screen, self.pfps[8], (px + 300, py + 260), self.down) == 1: self.tempPFP = 9
            if self.tempPFP == 1: self.screen.blit(self.selected, (px + 15, py + 13))
            if self.tempPFP == 2: self.screen.blit(self.selected, (px + 165, py + 13))
            if self.tempPFP == 3: self.screen.blit(self.selected, (px + 315, py + 13))
            if self.tempPFP == 4: self.screen.blit(self.selected, (px + 15, py + 140))
            if self.tempPFP == 5: self.screen.blit(self.selected, (px + 165, py + 140))
            if self.tempPFP == 6: self.screen.blit(self.selected, (px + 315, py + 140))
            if self.tempPFP == 7: self.screen.blit(self.selected, (px + 15, py + 270))
            if self.tempPFP == 8: self.screen.blit(self.selected, (px + 165, py + 270))
            if self.tempPFP == 9: self.screen.blit(self.selected, (px + 315, py + 270))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False                                             
                    quitApp(self.userdata, self.msgdata)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        quitApp(self.userdata, self.msgdata)
                    elif event.key == pygame.K_BACKSPACE:
                        self.typing_username = self.typing_username[:-1]
                    elif event.key == pygame.K_RETURN and self.typing_username:
                        self.userdata["Name"] = self.typing_username
                        self.userdata["started"] = True
                        self.userdata["pfp"] = str(self.pfps[self.tempPFP - 1])
                        save_user(self.userdata)
                    elif len(self.typing_username) < 17 and event.unicode.isprintable():
                        self.typing_username += event.unicode
                if event.type == pygame.MOUSEBUTTONUP:
                    self.down = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.down = True

            pygame.display.update()

        while self.running:
            self.screen.fill((0, 0, 0))
            self.screen.blit(self.chatBG, (0, 0))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False                                             
                    quitApp(self.userdata)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        quitApp(self.userdata, self.msgdata)
                    if event.key == pygame.K_RIGHT:
                        current_time = datetime.datetime.now()
                        formatted_time = current_time.strftime('%I:%M%p').lower()
                        self.messages.receive_message(['This is a test message which is made','to be very long!'], self.example_user, formatted_time)
                    if event.key == pygame.K_LEFT:
                        self.messages.erase(self.userdata)
                    if event.key == pygame.K_RETURN:
                        if self.user_text != '':
                            current_time = datetime.datetime.now()
                            formatted_time = current_time.strftime('%I:%M%p').lower()
                            self.messages.send_message(self.wrapped_text, formatted_time) 
                            self.user_text = "" 
                    elif event.key == pygame.K_BACKSPACE: 
                        self.user_text = self.user_text[:-1] 
                    else:
                        if self.canType:
                            self.user_text += event.unicode 
                if event.type == pygame.MOUSEBUTTONUP:
                    self.down = False
                if event.type == pygame.MOUSEBUTTONDOWN:
                    self.down = True

            self.messages.update()  
            self.wrapped_text = wrap_text(self.user_text, self.FONT, 850)

            try:
                if len(self.wrapped_text) > 2: 
                    self.canType = False
                else: 
                    self.canType = True
            except: 
                self.canType = True
            
            cursor_color1 = (84, 84, 84)  
            cursor_color2 = (142, 239, 195)  
            cursor_color = cursor_color1 if pygame.time.get_ticks() // 500 % 2 else cursor_color2

            if button(self.screen, 'ui/clear.png', (25, 975), self.down, (85, 85)) == 1: 
                self.messages.erase(self.userdata)

            pos = 950
            cursor_x = 600 
            cursor_y = pos  
            last_line = ""

            for i, line in enumerate(self.wrapped_text):
                if pos > 1000:
                    break 

                text_surface = self.FONT.render(line, True, (84, 84, 84))
                self.screen.blit(text_surface, (600, pos))

                last_line = line  
                cursor_y = pos  
                pos += 50

            text_width = self.FONT.size(last_line)[0]  
            cursor_x = 570 + text_width 

            cursor_surface = self.cursor_font.render("|", True, cursor_color)
            self.screen.blit(cursor_surface, (cursor_x, cursor_y))

            pygame.display.update()

app_instance = App()
app_instance.app()
