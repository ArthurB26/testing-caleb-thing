import pygame
import json
import sys
import os

default_data = {
    "Name": 'User',
    "pfp": "images/pfp/1.png",
    "started": False,
}

default_msg = {
    'data': [],
}

def get_data(type):
    file_path = f'data/{type}'

    if not os.path.exists(file_path):
        with open(file_path, 'w') as file:
            json.dump(default_msg if type == 'msg' else default_data, file, indent=4)

    try:
        with open(file_path, 'r') as file:
            data = json.load(file)
            if type == 'msg' and not isinstance(data, dict):
                data = {'data': data}
                save_data(data)
            return data
    except (json.JSONDecodeError, FileNotFoundError):
        with open(file_path, 'w') as file:
            json.dump(default_msg if type == 'msg' else default_data, file, indent=4)
        return default_msg if type == 'msg' else default_data

def save_data(data):  
    if isinstance(data, list):
        data = {'data': data}
    with open('data/msg', 'w') as data_file:
        json.dump(data, data_file, indent=4)
def save_user(data):  
    if isinstance(data, list):
        data = {'data': data}
    with open('data/user', 'w') as data_file:
        json.dump(data, data_file, indent=4)

def quitApp(data, msg):  
    with open('data/user', 'w') as data_file:
        json.dump(data, data_file, indent=4)
    with open('data/msg', 'w') as data_file:
        json.dump(msg, data_file, indent=4)
    print('App saved & quit!')
    pygame.quit()
    sys.exit()
