import pygame

def button(screen, img, pos, down, size=(120, 120)):
    mouse = pygame.mouse.get_pos()
    img = pygame.transform.scale(pygame.image.load(f'images/{img}'), size)
    screen.blit(img, pos)
    rect = img.get_rect()
    rect.y = pos[1]
    rect.x = pos[0]
    if down and rect.collidepoint(mouse[0], mouse[1]):
        return 1
    return 2
