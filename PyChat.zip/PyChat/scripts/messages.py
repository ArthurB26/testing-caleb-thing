import pygame
import socket
import threading
import json
from scripts.data import get_data, save_data, quitApp

class Messages:
    def __init__(self, user, screen):
        self.FONT = pygame.font.Font('images/font.ttf', 40)
        self.LilFONT = pygame.font.Font('images/font.ttf', 25)
        self.screen = screen
        self.user = user
        self.msgdata = get_data('msg').get('data', [])
        
        # Setup socket connection
        self.client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.server_ip = "192.168.137.1"  # Replace with actual server IP
        self.server_port = 5000  # Ensure this matches the server
        try:
            self.client_socket.connect((self.server_ip, self.server_port))
            threading.Thread(target=self.listen_for_messages, daemon=True).start()
        except Exception as e:
            print("Failed to connect to server:", e)

    def send_message(self, msg, time):
        for item in self.msgdata:
            item[3] -= 150
        self.msgdata.append([msg, self.user, time, 800, True])
        save_data(self.msgdata)
        
        # Send message to server
        message_packet = json.dumps({"msg": msg, "user": self.user, "time": time})
        try:
            self.client_socket.sendall(message_packet.encode('utf-8'))
        except Exception as e:
            print("Error sending message to server:", e)
        
    def receive_message(self, msg, user, time):
        for item in self.msgdata:
            item[3] -= 150
        self.msgdata.append([msg, user, time, 800, False])
        save_data(self.msgdata)
        
    def listen_for_messages(self):
        while True:
            try:
                data = self.client_socket.recv(4096).decode('utf-8')
                if not data:
                    break
                message_data = json.loads(data)
                self.receive_message(message_data['msg'], message_data['user'], message_data['time'])
            except Exception as e:
                print("Error receiving message from server:", e)
                break
    
    def update(self):
        for item in self.msgdata:
            if item[4]:
                self.screen.blit(pygame.image.load('images/ui/LeftSpeech.png'), (510, item[3] - 10))
                pos = item[3]
                second = False
                for line in item[0]: 
                    text_surface = self.FONT.render(line, True, (84, 84, 84))
                    self.screen.blit(text_surface, (600, pos))
                    pos += 40
                    if second:
                        break
                    else: second = True
                
                pfp = pygame.transform.scale(pygame.image.load(f'images/{self.user.get("pfp")}'), (50, 50))
                self.screen.blit(pfp, (510, item[3]))
                name_surface = self.FONT.render('YOU', True, (142, 239, 195))
                self.screen.blit(name_surface, (580, item[3] - 50))
                time = self.LilFONT.render(item[2], True, (142, 239, 195)) 
                self.screen.blit(time, (1320, item[3] - 40))
            else:
                self.screen.blit(pygame.image.load('images/ui/RightSpeech.png'), (920, item[3] - 10))
                pos = item[3]
                second = False
                for line in item[0]: 
                    text_surface = self.FONT.render(line, True, (84, 84, 84))
                    self.screen.blit(text_surface, (950, pos))
                    pos += 40
                    if second:
                        break
                    else: second = True
                
                pfp = pygame.transform.scale(pygame.image.load(f'images/pfp/{item[1].get("pfp")}'), (50, 50))
                self.screen.blit(pfp, (1820, item[3]))
                name_surface = self.FONT.render(item[1].get('Name'), True, (142, 239, 195))
                length = 1800
                for i in item[1].get('Name'):
                    length -= 23
                self.screen.blit(name_surface, (length, item[3] - 50))
                time = self.LilFONT.render(item[2], True, (142, 239, 195)) 
                self.screen.blit(time, (950, item[3] - 40))
    
    def erase(self, userdata):
        self.msgdata = {'data': []}
        save_data(self.msgdata)
        userdata = {
    "Name": "User",
    "pfp": "1.png",
    "started": False
}
        quitApp(userdata, self.msgdata)
